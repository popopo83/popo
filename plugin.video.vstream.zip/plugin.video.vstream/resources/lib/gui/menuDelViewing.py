import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.vstream/?site=cViewing&function=delViewingMenu)", True)
